package com.agrosense.lite;
import android.Manifest;
import android.content.pm.PackageManager;
import android.os.Bundle;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;
public class MainActivity extends AppCompatActivity {
    private static final int REQ_LOC = 10;
    EditText edtCropType, edtStage, edtMoisture;
    TextView tvNetStatus, txtLocation, txtRecommendation, txtSaved;
    Button btnGetLocation, btnRecommend, btnSave, btnShow;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        edtCropType = findViewById(R.id.edtCropType);
        edtStage = findViewById(R.id.edtStage);
        edtMoisture = findViewById(R.id.edtMoisture);
        tvNetStatus = findViewById(R.id.tvNetStatus);
        txtLocation = findViewById(R.id.txtLocation);
        txtRecommendation = findViewById(R.id.txtRecommendation);
        txtSaved = findViewById(R.id.txtSaved);
        btnGetLocation = findViewById(R.id.btnGetLocation);
        btnRecommend = findViewById(R.id.btnRecommend);
        btnSave = findViewById(R.id.btnSave);
        btnShow = findViewById(R.id.btnShow);
        tvNetStatus.setText(NetworkClient.isOnline(this) ? "Online available" : "Offline mode");
        btnGetLocation.setOnClickListener(v -> {
            if (ActivityCompat.checkSelfPermission(this, Manifest.permission.ACCESS_FINE_LOCATION) != PackageManager.PERMISSION_GRANTED) {
                ActivityCompat.requestPermissions(this, new String[]{Manifest.permission.ACCESS_FINE_LOCATION}, REQ_LOC);
            } else {
                txtLocation.setText(LocationHelper.getQuickLocationString(this));
            }
        });
        btnRecommend.setOnClickListener(v -> {
            String type = edtCropType.getText().toString().trim();
            String stage = edtStage.getText().toString().trim();
            double m = 0; try { m = Double.parseDouble(edtMoisture.getText().toString().trim()); } catch (Exception ignored) {}
            String rec = AIEngine.getRecommendation(type, stage, m);
            txtRecommendation.setText(rec + "\n\n(GMO hint: " + AIEngine.classifyGMO("","") + ")");
        });
        btnSave.setOnClickListener(v -> {
            StorageUtils.save(this, "last_rec", txtRecommendation.getText().toString());
            Toast.makeText(this, "Saved", Toast.LENGTH_SHORT).show();
        });
        btnShow.setOnClickListener(v -> {
            String saved = StorageUtils.get(this, "last_rec");
            txtSaved.setText(saved.isEmpty() ? "Nothing saved yet" : saved);
        });
    }
    @Override
    public void onRequestPermissionsResult(int requestCode, String[] permissions, int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        if (requestCode == REQ_LOC) {
            if (grantResults.length > 0 && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
                txtLocation.setText(LocationHelper.getQuickLocationString(this));
            } else {
                Toast.makeText(this, "Location permission denied", Toast.LENGTH_SHORT).show();
            }
        }
    }
}
