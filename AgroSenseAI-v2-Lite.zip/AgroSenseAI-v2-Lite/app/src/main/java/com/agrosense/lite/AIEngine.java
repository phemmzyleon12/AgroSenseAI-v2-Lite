package com.agrosense.lite;
public class AIEngine {
    public static String getRecommendation(String cropType, String growthStage, double moisture) {
        cropType = cropType == null ? "" : cropType.toLowerCase();
        growthStage = growthStage == null ? "" : growthStage.toLowerCase();
        if (cropType.contains("maize") || cropType.contains("corn")) {
            if (growthStage.contains("seed")) {
                if (moisture < 30) return "Irrigate lightly. Apply starter NPK (low dose).";
                return "No fertilizer now. Monitor for pests.";
            } else if (growthStage.contains("vegetative")) {
                if (moisture < 40) return "Irrigate and apply nitrogen (urea).";
                return "Apply balanced NPK; scout weeds/pests.";
            } else if (growthStage.contains("flower") || growthStage.contains("tassel")) {
                return "Apply potassium-rich fertilizer, consider foliar feed.";
            }
        }
        if (cropType.contains("rice")) {
            if (moisture < 50) return "Maintain water level; add nitrogen as needed.";
            return "Apply basal NPK; keep field adequately flooded.";
        }
        if (moisture < 30) return "Irrigate. Do soil test before fertilizing.";
        if (moisture < 50) return "Apply balanced NPK per label. Monitor.";
        return "Monitor crop; add foliar micronutrients if deficiency signs appear.";
    }
    public static String classifyGMO(String seedSource, String trait) {
        seedSource = seedSource == null ? "" : seedSource.toLowerCase();
        trait = trait == null ? "" : trait.toLowerCase();
        if (seedSource.contains("certified") || seedSource.contains("brand"))
            return "Likely commercial seed (hybrid or GMO). Check label/supplier to confirm.";
        if (trait.contains("herbicide") || trait.contains("bt") || trait.contains("resistant"))
            return "Traits suggest possible GMO (e.g., Bt/herbicide-resistant). Only lab test confirms.";
        if (seedSource.contains("farmer") || seedSource.contains("local"))
            return "Likely traditional/local seed (non-GMO), not guaranteed.";
        return "Unknown. Request documentation or lab testing to confirm.";
    }
}
