package com.agrosense.lite;
import android.content.Context;
import android.content.SharedPreferences;
public class StorageUtils {
    private static final String PREF = "agro_pref";
    public static void save(Context ctx, String key, String value) {
        try { ctx.getSharedPreferences(PREF, Context.MODE_PRIVATE).edit().putString(key, value).apply(); }
        catch (Exception ignored) {}
    }
    public static String get(Context ctx, String key) {
        try { return ctx.getSharedPreferences(PREF, Context.MODE_PRIVATE).getString(key, ""); }
        catch (Exception e) { return ""; }
    }
}
